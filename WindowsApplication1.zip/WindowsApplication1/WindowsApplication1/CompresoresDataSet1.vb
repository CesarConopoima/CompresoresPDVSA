﻿Partial Class CompresoresDataSet1
    Partial Class UsuarioDataTable

        Private Sub UsuarioDataTable_UsuarioRowChanging(sender As Object, e As UsuarioRowChangeEvent) Handles Me.UsuarioRowChanging

        End Sub

    End Class

End Class
