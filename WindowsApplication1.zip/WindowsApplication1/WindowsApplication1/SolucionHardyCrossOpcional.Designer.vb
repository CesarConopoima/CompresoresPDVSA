﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SolucionHardyCrossOpcional
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SolucionHardyCrossOpcional))
        Dim ChartArea3 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend3 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series3 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim ChartArea4 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend4 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series4 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Tub0 = New System.Windows.Forms.Label()
        Me.Tub1 = New System.Windows.Forms.Label()
        Me.Tub2 = New System.Windows.Forms.Label()
        Me.Tanque0 = New System.Windows.Forms.TextBox()
        Me.Tanque1 = New System.Windows.Forms.TextBox()
        Me.Tanque4 = New System.Windows.Forms.TextBox()
        Me.Valv1 = New System.Windows.Forms.HScrollBar()
        Me.NumBomba1480 = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Composicion_2 = New System.Windows.Forms.Label()
        Me.Valv2 = New System.Windows.Forms.HScrollBar()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Viscosidad2 = New System.Windows.Forms.Label()
        Me.VelValv2 = New System.Windows.Forms.Label()
        Me.VelValv1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Title = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Visco1 = New System.Windows.Forms.TextBox()
        Me.Densidad1 = New System.Windows.Forms.TextBox()
        Me.Visco2 = New System.Windows.Forms.TextBox()
        Me.Densidad2 = New System.Windows.Forms.TextBox()
        Me.Visco3 = New System.Windows.Forms.TextBox()
        Me.Densidad3 = New System.Windows.Forms.TextBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Chart1 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Chart2 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Viscosidad1 = New System.Windows.Forms.Label()
        Me.Compo1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Chart2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(872, 44)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(148, 31)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Calcular"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Tub0
        '
        Me.Tub0.AutoSize = True
        Me.Tub0.Location = New System.Drawing.Point(543, 362)
        Me.Tub0.Name = "Tub0"
        Me.Tub0.Size = New System.Drawing.Size(39, 13)
        Me.Tub0.TabIndex = 4
        Me.Tub0.Text = "Label1"
        '
        'Tub1
        '
        Me.Tub1.AutoSize = True
        Me.Tub1.Location = New System.Drawing.Point(402, 276)
        Me.Tub1.Name = "Tub1"
        Me.Tub1.Size = New System.Drawing.Size(39, 13)
        Me.Tub1.TabIndex = 5
        Me.Tub1.Text = "Label2"
        '
        'Tub2
        '
        Me.Tub2.AutoSize = True
        Me.Tub2.Location = New System.Drawing.Point(463, 94)
        Me.Tub2.Name = "Tub2"
        Me.Tub2.Size = New System.Drawing.Size(39, 13)
        Me.Tub2.TabIndex = 7
        Me.Tub2.Text = "Label3"
        '
        'Tanque0
        '
        Me.Tanque0.Location = New System.Drawing.Point(334, 422)
        Me.Tanque0.Name = "Tanque0"
        Me.Tanque0.Size = New System.Drawing.Size(51, 20)
        Me.Tanque0.TabIndex = 13
        '
        'Tanque1
        '
        Me.Tanque1.Location = New System.Drawing.Point(80, 300)
        Me.Tanque1.Name = "Tanque1"
        Me.Tanque1.Size = New System.Drawing.Size(51, 20)
        Me.Tanque1.TabIndex = 14
        '
        'Tanque4
        '
        Me.Tanque4.Location = New System.Drawing.Point(644, 94)
        Me.Tanque4.Name = "Tanque4"
        Me.Tanque4.Size = New System.Drawing.Size(51, 20)
        Me.Tanque4.TabIndex = 17
        '
        'Valv1
        '
        Me.Valv1.Location = New System.Drawing.Point(268, 307)
        Me.Valv1.Name = "Valv1"
        Me.Valv1.Size = New System.Drawing.Size(79, 13)
        Me.Valv1.TabIndex = 19
        '
        'NumBomba1480
        '
        Me.NumBomba1480.FormattingEnabled = True
        Me.NumBomba1480.Items.AddRange(New Object() {"1", "2", "3"})
        Me.NumBomba1480.Location = New System.Drawing.Point(420, 401)
        Me.NumBomba1480.Name = "NumBomba1480"
        Me.NumBomba1480.Size = New System.Drawing.Size(35, 21)
        Me.NumBomba1480.TabIndex = 21
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(386, 372)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(97, 26)
        Me.Label1.TabIndex = 22
        Me.Label1.Text = "      Seleccione el" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "número de bombas"
        '
        'Composicion_2
        '
        Me.Composicion_2.AutoSize = True
        Me.Composicion_2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Composicion_2.Location = New System.Drawing.Point(191, 385)
        Me.Composicion_2.Name = "Composicion_2"
        Me.Composicion_2.Size = New System.Drawing.Size(108, 13)
        Me.Composicion_2.TabIndex = 27
        Me.Composicion_2.Text = "Cambiar Composición"
        '
        'Valv2
        '
        Me.Valv2.Location = New System.Drawing.Point(546, 203)
        Me.Valv2.Name = "Valv2"
        Me.Valv2.Size = New System.Drawing.Size(79, 13)
        Me.Valv2.TabIndex = 31
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Viscosidad2)
        Me.GroupBox1.Controls.Add(Me.Viscosidad1)
        Me.GroupBox1.Controls.Add(Me.VelValv2)
        Me.GroupBox1.Controls.Add(Me.VelValv1)
        Me.GroupBox1.Controls.Add(Me.Tub0)
        Me.GroupBox1.Controls.Add(Me.Tanque0)
        Me.GroupBox1.Controls.Add(Me.Tanque4)
        Me.GroupBox1.Controls.Add(Me.Tanque1)
        Me.GroupBox1.Controls.Add(Me.Valv1)
        Me.GroupBox1.Controls.Add(Me.Valv2)
        Me.GroupBox1.Controls.Add(Me.Tub1)
        Me.GroupBox1.Controls.Add(Me.Compo1)
        Me.GroupBox1.Controls.Add(Me.Tub2)
        Me.GroupBox1.Controls.Add(Me.Composicion_2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.NumBomba1480)
        Me.GroupBox1.Controls.Add(Me.PictureBox1)
        Me.GroupBox1.Location = New System.Drawing.Point(9, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(784, 627)
        Me.GroupBox1.TabIndex = 32
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Sistema de bombas LNG"
        '
        'Viscosidad2
        '
        Me.Viscosidad2.AutoSize = True
        Me.Viscosidad2.Location = New System.Drawing.Point(184, 409)
        Me.Viscosidad2.Name = "Viscosidad2"
        Me.Viscosidad2.Size = New System.Drawing.Size(126, 13)
        Me.Viscosidad2.TabIndex = 37
        Me.Viscosidad2.Text = "Viscosidad de la mezcla2"
        '
        'VelValv2
        '
        Me.VelValv2.AutoSize = True
        Me.VelValv2.Location = New System.Drawing.Point(561, 220)
        Me.VelValv2.Name = "VelValv2"
        Me.VelValv2.Size = New System.Drawing.Size(49, 13)
        Me.VelValv2.TabIndex = 35
        Me.VelValv2.Text = "VelValv2"
        '
        'VelValv1
        '
        Me.VelValv1.AutoSize = True
        Me.VelValv1.Location = New System.Drawing.Point(287, 334)
        Me.VelValv1.Name = "VelValv1"
        Me.VelValv1.Size = New System.Drawing.Size(49, 13)
        Me.VelValv1.TabIndex = 32
        Me.VelValv1.Text = "VelValv1"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(8, 15)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(723, 490)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Title
        '
        Me.Title.AutoSize = True
        Me.Title.BackColor = System.Drawing.Color.Transparent
        Me.Title.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Title.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Title.Location = New System.Drawing.Point(866, 81)
        Me.Title.Name = "Title"
        Me.Title.Size = New System.Drawing.Size(166, 16)
        Me.Title.TabIndex = 38
        Me.Title.Text = "Resumén de propiedades"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(818, 107)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(126, 13)
        Me.Label3.TabIndex = 38
        Me.Label3.Text = "Viscosidad de la mezcla1"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(817, 148)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(126, 13)
        Me.Label4.TabIndex = 39
        Me.Label4.Text = "Viscosidad de la mezcla2"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(818, 186)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(126, 13)
        Me.Label5.TabIndex = 40
        Me.Label5.Text = "Viscosidad de la mezcla3"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(953, 109)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(120, 13)
        Me.Label6.TabIndex = 41
        Me.Label6.Text = "Densidad de la mezcla1"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(953, 149)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(120, 13)
        Me.Label7.TabIndex = 42
        Me.Label7.Text = "Densidad de la mezcla1"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(952, 185)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(120, 13)
        Me.Label8.TabIndex = 43
        Me.Label8.Text = "Densidad de la mezcla1"
        '
        'Visco1
        '
        Me.Visco1.Location = New System.Drawing.Point(856, 124)
        Me.Visco1.Name = "Visco1"
        Me.Visco1.Size = New System.Drawing.Size(51, 20)
        Me.Visco1.TabIndex = 44
        '
        'Densidad1
        '
        Me.Densidad1.Location = New System.Drawing.Point(981, 124)
        Me.Densidad1.Name = "Densidad1"
        Me.Densidad1.Size = New System.Drawing.Size(51, 20)
        Me.Densidad1.TabIndex = 45
        '
        'Visco2
        '
        Me.Visco2.Location = New System.Drawing.Point(856, 164)
        Me.Visco2.Name = "Visco2"
        Me.Visco2.Size = New System.Drawing.Size(51, 20)
        Me.Visco2.TabIndex = 46
        '
        'Densidad2
        '
        Me.Densidad2.Location = New System.Drawing.Point(981, 164)
        Me.Densidad2.Name = "Densidad2"
        Me.Densidad2.Size = New System.Drawing.Size(51, 20)
        Me.Densidad2.TabIndex = 47
        '
        'Visco3
        '
        Me.Visco3.Location = New System.Drawing.Point(856, 202)
        Me.Visco3.Name = "Visco3"
        Me.Visco3.Size = New System.Drawing.Size(51, 20)
        Me.Visco3.TabIndex = 48
        '
        'Densidad3
        '
        Me.Densidad3.Location = New System.Drawing.Point(981, 201)
        Me.Densidad3.Name = "Densidad3"
        Me.Densidad3.Size = New System.Drawing.Size(51, 20)
        Me.Densidad3.TabIndex = 49
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 500
        '
        'Chart1
        '
        ChartArea3.Name = "ChartArea1"
        Me.Chart1.ChartAreas.Add(ChartArea3)
        Legend3.Name = "Legend1"
        Me.Chart1.Legends.Add(Legend3)
        Me.Chart1.Location = New System.Drawing.Point(698, 235)
        Me.Chart1.Name = "Chart1"
        Series3.ChartArea = "ChartArea1"
        Series3.Font = New System.Drawing.Font("Microsoft Sans Serif", 5.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Series3.Legend = "Legend1"
        Series3.Name = "Series1"
        Me.Chart1.Series.Add(Series3)
        Me.Chart1.Size = New System.Drawing.Size(375, 193)
        Me.Chart1.TabIndex = 50
        Me.Chart1.Text = "Chart3"
        '
        'Chart2
        '
        ChartArea4.Name = "ChartArea1"
        Me.Chart2.ChartAreas.Add(ChartArea4)
        Legend4.Name = "Legend1"
        Me.Chart2.Legends.Add(Legend4)
        Me.Chart2.Location = New System.Drawing.Point(698, 442)
        Me.Chart2.Name = "Chart2"
        Series4.ChartArea = "ChartArea1"
        Series4.Legend = "Legend1"
        Series4.Name = "Series1"
        Me.Chart2.Series.Add(Series4)
        Me.Chart2.Size = New System.Drawing.Size(375, 193)
        Me.Chart2.TabIndex = 51
        Me.Chart2.Text = "Chart4"
        '
        'Viscosidad1
        '
        Me.Viscosidad1.AutoSize = True
        Me.Viscosidad1.Location = New System.Drawing.Point(173, 241)
        Me.Viscosidad1.Name = "Viscosidad1"
        Me.Viscosidad1.Size = New System.Drawing.Size(126, 13)
        Me.Viscosidad1.TabIndex = 36
        Me.Viscosidad1.Text = "Viscosidad de la mezcla1"
        '
        'Compo1
        '
        Me.Compo1.AutoSize = True
        Me.Compo1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Compo1.Location = New System.Drawing.Point(184, 218)
        Me.Compo1.Name = "Compo1"
        Me.Compo1.Size = New System.Drawing.Size(108, 13)
        Me.Compo1.TabIndex = 26
        Me.Compo1.Text = "Cambiar Composición"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(581, 121)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(132, 26)
        Me.Label2.TabIndex = 38
        Me.Label2.Text = "    1046 GPM = 66 L/s" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Como Punto de Operación" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'SolucionHardyCrossOpcional
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(1099, 647)
        Me.Controls.Add(Me.Chart2)
        Me.Controls.Add(Me.Chart1)
        Me.Controls.Add(Me.Densidad3)
        Me.Controls.Add(Me.Visco3)
        Me.Controls.Add(Me.Densidad2)
        Me.Controls.Add(Me.Visco2)
        Me.Controls.Add(Me.Densidad1)
        Me.Controls.Add(Me.Visco1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Title)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Button1)
        Me.Name = "SolucionHardyCrossOpcional"
        Me.Text = "SolucionHardyCross"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Chart2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Tub0 As System.Windows.Forms.Label
    Friend WithEvents Tub1 As System.Windows.Forms.Label
    Friend WithEvents Tub2 As System.Windows.Forms.Label
    Friend WithEvents Tanque0 As System.Windows.Forms.TextBox
    Friend WithEvents Tanque1 As System.Windows.Forms.TextBox
    Friend WithEvents Tanque4 As System.Windows.Forms.TextBox
    Friend WithEvents Valv1 As System.Windows.Forms.HScrollBar
    Friend WithEvents NumBomba1480 As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Composicion_2 As System.Windows.Forms.Label
    Friend WithEvents Valv2 As System.Windows.Forms.HScrollBar
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents VelValv1 As System.Windows.Forms.Label
    Friend WithEvents VelValv2 As System.Windows.Forms.Label
    Friend WithEvents Viscosidad2 As System.Windows.Forms.Label
    Friend WithEvents Title As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Visco1 As System.Windows.Forms.TextBox
    Friend WithEvents Densidad1 As System.Windows.Forms.TextBox
    Friend WithEvents Visco2 As System.Windows.Forms.TextBox
    Friend WithEvents Densidad2 As System.Windows.Forms.TextBox
    Friend WithEvents Visco3 As System.Windows.Forms.TextBox
    Friend WithEvents Densidad3 As System.Windows.Forms.TextBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Chart1 As System.Windows.Forms.DataVisualization.Charting.Chart
    Friend WithEvents Chart2 As System.Windows.Forms.DataVisualization.Charting.Chart
    Friend WithEvents Viscosidad1 As System.Windows.Forms.Label
    Friend WithEvents Compo1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
End Class
