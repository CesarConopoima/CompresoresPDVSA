﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LNGComposicion
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.N2 = New System.Windows.Forms.TextBox()
        Me.C1 = New System.Windows.Forms.TextBox()
        Me.C2 = New System.Windows.Forms.TextBox()
        Me.CO2 = New System.Windows.Forms.TextBox()
        Me.C3 = New System.Windows.Forms.TextBox()
        Me.IC4 = New System.Windows.Forms.TextBox()
        Me.NC4 = New System.Windows.Forms.TextBox()
        Me.IC5 = New System.Windows.Forms.TextBox()
        Me.C6 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.NC5 = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TempMezclaUnits = New System.Windows.Forms.ComboBox()
        Me.id = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(97, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(182, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Composición del LNG "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(46, 316)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(25, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "N2"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(46, 78)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(25, 15)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "C1"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(46, 161)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 15)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "IC4"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(46, 343)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 15)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "CO2"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(46, 135)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(25, 15)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "C3"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(46, 107)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(25, 15)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "C2"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(46, 267)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(33, 15)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "C6+"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(46, 241)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(35, 15)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "NC5"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(46, 213)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(29, 15)
        Me.Label12.TabIndex = 11
        Me.Label12.Text = "IC5"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(46, 187)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(35, 15)
        Me.Label13.TabIndex = 12
        Me.Label13.Text = "NC4"
        '
        'N2
        '
        Me.N2.Location = New System.Drawing.Point(109, 312)
        Me.N2.Name = "N2"
        Me.N2.Size = New System.Drawing.Size(50, 20)
        Me.N2.TabIndex = 13
        '
        'C1
        '
        Me.C1.Location = New System.Drawing.Point(109, 76)
        Me.C1.Name = "C1"
        Me.C1.Size = New System.Drawing.Size(50, 20)
        Me.C1.TabIndex = 14
        '
        'C2
        '
        Me.C2.Location = New System.Drawing.Point(110, 104)
        Me.C2.Name = "C2"
        Me.C2.Size = New System.Drawing.Size(50, 20)
        Me.C2.TabIndex = 15
        '
        'CO2
        '
        Me.CO2.Location = New System.Drawing.Point(109, 338)
        Me.CO2.Name = "CO2"
        Me.CO2.Size = New System.Drawing.Size(50, 20)
        Me.CO2.TabIndex = 16
        '
        'C3
        '
        Me.C3.Location = New System.Drawing.Point(109, 130)
        Me.C3.Name = "C3"
        Me.C3.Size = New System.Drawing.Size(50, 20)
        Me.C3.TabIndex = 18
        '
        'IC4
        '
        Me.IC4.Location = New System.Drawing.Point(110, 156)
        Me.IC4.Name = "IC4"
        Me.IC4.Size = New System.Drawing.Size(50, 20)
        Me.IC4.TabIndex = 19
        '
        'NC4
        '
        Me.NC4.Location = New System.Drawing.Point(109, 182)
        Me.NC4.Name = "NC4"
        Me.NC4.Size = New System.Drawing.Size(50, 20)
        Me.NC4.TabIndex = 20
        '
        'IC5
        '
        Me.IC5.Location = New System.Drawing.Point(109, 208)
        Me.IC5.Name = "IC5"
        Me.IC5.Size = New System.Drawing.Size(50, 20)
        Me.IC5.TabIndex = 21
        '
        'C6
        '
        Me.C6.Location = New System.Drawing.Point(109, 262)
        Me.C6.Name = "C6"
        Me.C6.Size = New System.Drawing.Size(50, 20)
        Me.C6.TabIndex = 23
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(230, 140)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(50, 20)
        Me.TextBox1.TabIndex = 24
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(171, 120)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(176, 15)
        Me.Label9.TabIndex = 25
        Me.Label9.Text = "Peso Molecular [Kg/Kmol]"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(192, 164)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(145, 15)
        Me.Label14.TabIndex = 26
        Me.Label14.Text = "Presión Crítica [psia]"
        '
        'NC5
        '
        Me.NC5.Location = New System.Drawing.Point(109, 236)
        Me.NC5.Name = "NC5"
        Me.NC5.Size = New System.Drawing.Size(50, 20)
        Me.NC5.TabIndex = 27
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(171, 205)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(162, 15)
        Me.Label15.TabIndex = 28
        Me.Label15.Text = "Temperatura Crítica [R]"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(230, 184)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(50, 20)
        Me.TextBox2.TabIndex = 29
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(230, 227)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(50, 20)
        Me.TextBox3.TabIndex = 30
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(100, 436)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(161, 43)
        Me.Button1.TabIndex = 33
        Me.Button1.Text = "Determinar Características y Guardar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(191, 316)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(139, 26)
        Me.Button2.TabIndex = 34
        Me.Button2.Text = "Habilitar Contaminantes"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Arial Rounded MT Bold", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(216, 95)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(81, 17)
        Me.Label17.TabIndex = 35
        Me.Label17.Text = "Resultado"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(52, 37)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(280, 28)
        Me.Label18.TabIndex = 36
        Me.Label18.Text = "   Anote en terminos porcentuales del 0 al 100" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "deje en blanco para los valores q" & _
    "ue no conozca"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(54, 294)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(106, 15)
        Me.Label6.TabIndex = 37
        Me.Label6.Text = "Contaminantes"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(171, 248)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(189, 15)
        Me.Label16.TabIndex = 38
        Me.Label16.Text = "Viscosidad Equivalente [Cp]"
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(230, 268)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(50, 20)
        Me.TextBox4.TabIndex = 39
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(18, 372)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(175, 15)
        Me.Label19.TabIndex = 40
        Me.Label19.Text = "Temperatura de la Mezcla"
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(244, 370)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(50, 20)
        Me.TextBox5.TabIndex = 41
        '
        'TempMezclaUnits
        '
        Me.TempMezclaUnits.FormattingEnabled = True
        Me.TempMezclaUnits.Items.AddRange(New Object() {"[°C]", "[K]", "[F]", "[R]"})
        Me.TempMezclaUnits.Location = New System.Drawing.Point(202, 370)
        Me.TempMezclaUnits.Name = "TempMezclaUnits"
        Me.TempMezclaUnits.Size = New System.Drawing.Size(33, 21)
        Me.TempMezclaUnits.TabIndex = 42
        '
        'id
        '
        Me.id.AutoSize = True
        Me.id.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.id.Location = New System.Drawing.Point(188, 69)
        Me.id.Name = "id"
        Me.id.Size = New System.Drawing.Size(0, 15)
        Me.id.TabIndex = 43
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(18, 401)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(140, 15)
        Me.Label20.TabIndex = 44
        Me.Label20.Text = "Gravedad especifica"
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(244, 399)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(50, 20)
        Me.TextBox6.TabIndex = 45
        '
        'LNGComposicion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(368, 482)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.id)
        Me.Controls.Add(Me.TempMezclaUnits)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.NC5)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.C6)
        Me.Controls.Add(Me.IC5)
        Me.Controls.Add(Me.NC4)
        Me.Controls.Add(Me.IC4)
        Me.Controls.Add(Me.C3)
        Me.Controls.Add(Me.CO2)
        Me.Controls.Add(Me.C2)
        Me.Controls.Add(Me.C1)
        Me.Controls.Add(Me.N2)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "LNGComposicion"
        Me.Text = "Composición del LNG"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents N2 As System.Windows.Forms.TextBox
    Friend WithEvents C1 As System.Windows.Forms.TextBox
    Friend WithEvents C2 As System.Windows.Forms.TextBox
    Friend WithEvents CO2 As System.Windows.Forms.TextBox
    Friend WithEvents C3 As System.Windows.Forms.TextBox
    Friend WithEvents IC4 As System.Windows.Forms.TextBox
    Friend WithEvents NC4 As System.Windows.Forms.TextBox
    Friend WithEvents IC5 As System.Windows.Forms.TextBox
    Friend WithEvents C6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents NC5 As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TempMezclaUnits As System.Windows.Forms.ComboBox
    Friend WithEvents id As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
End Class
