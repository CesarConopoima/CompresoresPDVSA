﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SantaBarbara_Compresores
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim TabPage1 As System.Windows.Forms.TabPage
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SantaBarbara_Compresores))
        Me.InfoGlobal = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.InfoCondensado = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.InfoEnfriador1 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.InfoCompre2 = New System.Windows.Forms.Label()
        Me.InfoCompre1 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.RelacionCompresion = New System.Windows.Forms.Label()
        Me.Titulo = New System.Windows.Forms.Label()
        Me.NombreMaquina = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.TempRucio = New System.Windows.Forms.Label()
        Me.TextDescargaCompresor2 = New System.Windows.Forms.Label()
        Me.TextTempIntercambiador = New System.Windows.Forms.Label()
        Me.TextDescargaCompresor1 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ProgramaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CerrarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReporteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GenerarReporteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AyudaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AbrirAyudaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AyudaTécnicaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FlujoVolumetricoUnidades = New System.Windows.Forms.GroupBox()
        Me.TemperaturaUnidades = New System.Windows.Forms.ComboBox()
        Me.TempAeroenfriador = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.FlujoVolumetrico = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Potencia = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.RPM = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Area = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.PresionUnidades = New System.Windows.Forms.ComboBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.FlujoMasico = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Tdescarga = New System.Windows.Forms.TextBox()
        Me.Pdescarga = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Diametro = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.HumedadAbsoluta = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Stroke = New System.Windows.Forms.TextBox()
        Me.HumedadRelativa = New System.Windows.Forms.TextBox()
        Me.Tambiental = New System.Windows.Forms.TextBox()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        TabPage1 = New System.Windows.Forms.TabPage()
        TabPage1.SuspendLayout()
        Me.NombreMaquina.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.FlujoVolumetricoUnidades.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabPage1
        '
        TabPage1.Controls.Add(Me.InfoGlobal)
        TabPage1.Controls.Add(Me.Label30)
        TabPage1.Controls.Add(Me.InfoCondensado)
        TabPage1.Controls.Add(Me.Label29)
        TabPage1.Controls.Add(Me.InfoEnfriador1)
        TabPage1.Controls.Add(Me.Label28)
        TabPage1.Controls.Add(Me.InfoCompre2)
        TabPage1.Controls.Add(Me.InfoCompre1)
        TabPage1.Controls.Add(Me.Label26)
        TabPage1.Controls.Add(Me.Label27)
        TabPage1.Controls.Add(Me.RelacionCompresion)
        TabPage1.Controls.Add(Me.Titulo)
        TabPage1.Location = New System.Drawing.Point(4, 22)
        TabPage1.Name = "TabPage1"
        TabPage1.Padding = New System.Windows.Forms.Padding(3)
        TabPage1.Size = New System.Drawing.Size(437, 304)
        TabPage1.TabIndex = 0
        TabPage1.Text = "Información de Interés"
        TabPage1.UseVisualStyleBackColor = True
        '
        'InfoGlobal
        '
        Me.InfoGlobal.AutoSize = True
        Me.InfoGlobal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InfoGlobal.Location = New System.Drawing.Point(149, 256)
        Me.InfoGlobal.Name = "InfoGlobal"
        Me.InfoGlobal.Size = New System.Drawing.Size(48, 15)
        Me.InfoGlobal.TabIndex = 13
        Me.InfoGlobal.Text = "Valor5"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(80, 225)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(281, 13)
        Me.Label30.TabIndex = 12
        Me.Label30.Text = "Relación de compresión global y potencia total consumida"
        '
        'InfoCondensado
        '
        Me.InfoCondensado.AutoSize = True
        Me.InfoCondensado.Location = New System.Drawing.Point(259, 185)
        Me.InfoCondensado.Name = "InfoCondensado"
        Me.InfoCondensado.Size = New System.Drawing.Size(37, 13)
        Me.InfoCondensado.TabIndex = 11
        Me.InfoCondensado.Text = "Valor4"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(35, 185)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(162, 13)
        Me.Label29.TabIndex = 10
        Me.Label29.Text = "Condensado de agua en la línea"
        '
        'InfoEnfriador1
        '
        Me.InfoEnfriador1.AutoSize = True
        Me.InfoEnfriador1.Location = New System.Drawing.Point(259, 144)
        Me.InfoEnfriador1.Name = "InfoEnfriador1"
        Me.InfoEnfriador1.Size = New System.Drawing.Size(37, 13)
        Me.InfoEnfriador1.TabIndex = 9
        Me.InfoEnfriador1.Text = "Valor3"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(35, 144)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(192, 13)
        Me.Label28.TabIndex = 8
        Me.Label28.Text = "Temperatura despues del aeroenfriador"
        '
        'InfoCompre2
        '
        Me.InfoCompre2.AutoSize = True
        Me.InfoCompre2.Location = New System.Drawing.Point(141, 105)
        Me.InfoCompre2.Name = "InfoCompre2"
        Me.InfoCompre2.Size = New System.Drawing.Size(37, 13)
        Me.InfoCompre2.TabIndex = 7
        Me.InfoCompre2.Text = "Valor2"
        '
        'InfoCompre1
        '
        Me.InfoCompre1.AutoSize = True
        Me.InfoCompre1.Location = New System.Drawing.Point(141, 81)
        Me.InfoCompre1.Name = "InfoCompre1"
        Me.InfoCompre1.Size = New System.Drawing.Size(37, 13)
        Me.InfoCompre1.TabIndex = 6
        Me.InfoCompre1.Text = "Valor1"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(54, 105)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(69, 13)
        Me.Label26.TabIndex = 5
        Me.Label26.Text = "Compresor 2:"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(54, 81)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(69, 13)
        Me.Label27.TabIndex = 4
        Me.Label27.Text = "Compresor 1:"
        '
        'RelacionCompresion
        '
        Me.RelacionCompresion.AutoSize = True
        Me.RelacionCompresion.Location = New System.Drawing.Point(35, 54)
        Me.RelacionCompresion.Name = "RelacionCompresion"
        Me.RelacionCompresion.Size = New System.Drawing.Size(362, 13)
        Me.RelacionCompresion.TabIndex = 2
        Me.RelacionCompresion.Text = "Relación de compresión, temperatura en la descarga y potencia consumida"
        '
        'Titulo
        '
        Me.Titulo.AutoSize = True
        Me.Titulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Titulo.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Titulo.Location = New System.Drawing.Point(44, 15)
        Me.Titulo.Name = "Titulo"
        Me.Titulo.Size = New System.Drawing.Size(356, 24)
        Me.Titulo.TabIndex = 1
        Me.Titulo.Text = "Resumen del sistema de compresión"
        '
        'NombreMaquina
        '
        Me.NombreMaquina.Controls.Add(Me.GroupBox3)
        Me.NombreMaquina.Controls.Add(Me.GroupBox2)
        Me.NombreMaquina.Controls.Add(Me.MenuStrip1)
        Me.NombreMaquina.Location = New System.Drawing.Point(2, 3)
        Me.NombreMaquina.Name = "NombreMaquina"
        Me.NombreMaquina.Size = New System.Drawing.Size(1170, 261)
        Me.NombreMaquina.TabIndex = 0
        Me.NombreMaquina.TabStop = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.TempRucio)
        Me.GroupBox3.Controls.Add(Me.TextDescargaCompresor2)
        Me.GroupBox3.Controls.Add(Me.TextTempIntercambiador)
        Me.GroupBox3.Controls.Add(Me.TextDescargaCompresor1)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.Label19)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Controls.Add(Me.PictureBox1)
        Me.GroupBox3.Location = New System.Drawing.Point(234, 0)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(933, 255)
        Me.GroupBox3.TabIndex = 1
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Sistema de Compresión de aire para Jusepin"
        '
        'TempRucio
        '
        Me.TempRucio.AutoSize = True
        Me.TempRucio.Location = New System.Drawing.Point(276, 31)
        Me.TempRucio.Name = "TempRucio"
        Me.TempRucio.Size = New System.Drawing.Size(67, 26)
        Me.TempRucio.TabIndex = 8
        Me.TempRucio.Text = "Temperatura" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "    Gases"
        '
        'TextDescargaCompresor2
        '
        Me.TextDescargaCompresor2.AutoSize = True
        Me.TextDescargaCompresor2.Location = New System.Drawing.Point(542, 152)
        Me.TextDescargaCompresor2.Name = "TextDescargaCompresor2"
        Me.TextDescargaCompresor2.Size = New System.Drawing.Size(66, 26)
        Me.TextDescargaCompresor2.TabIndex = 7
        Me.TextDescargaCompresor2.Text = "Condiciones" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "  descarga 2"
        '
        'TextTempIntercambiador
        '
        Me.TextTempIntercambiador.AutoSize = True
        Me.TextTempIntercambiador.Location = New System.Drawing.Point(560, 107)
        Me.TextTempIntercambiador.Name = "TextTempIntercambiador"
        Me.TextTempIntercambiador.Size = New System.Drawing.Size(76, 26)
        Me.TextTempIntercambiador.TabIndex = 5
        Me.TextTempIntercambiador.Text = "Temperatura" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "intercambiador"
        '
        'TextDescargaCompresor1
        '
        Me.TextDescargaCompresor1.AutoSize = True
        Me.TextDescargaCompresor1.Location = New System.Drawing.Point(434, 152)
        Me.TextDescargaCompresor1.Name = "TextDescargaCompresor1"
        Me.TextDescargaCompresor1.Size = New System.Drawing.Size(66, 26)
        Me.TextDescargaCompresor1.TabIndex = 4
        Me.TextDescargaCompresor1.Text = "Condiciones" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "  descarga 1"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label13.Location = New System.Drawing.Point(252, 149)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(125, 13)
        Me.Label13.TabIndex = 3
        Me.Label13.Text = "Condiciones Ambientales"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label19.Location = New System.Drawing.Point(616, 207)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(88, 13)
        Me.Label19.TabIndex = 2
        Me.Label19.Text = "compresor_SB_2"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label12.Location = New System.Drawing.Point(344, 207)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(88, 13)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "compresor_SB_1"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(255, 16)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(459, 233)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label21)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Location = New System.Drawing.Point(6, 52)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(223, 114)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Planta"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(6, 86)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(103, 13)
        Me.Label21.TabIndex = 2
        Me.Label21.Text = "Nombre de la Planta"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(21, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(103, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Nombre de la Planta"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(54, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ID_Planta"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ProgramaToolStripMenuItem, Me.ReporteToolStripMenuItem, Me.AyudaToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(3, 16)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1164, 24)
        Me.MenuStrip1.TabIndex = 2
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ProgramaToolStripMenuItem
        '
        Me.ProgramaToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CerrarToolStripMenuItem})
        Me.ProgramaToolStripMenuItem.Name = "ProgramaToolStripMenuItem"
        Me.ProgramaToolStripMenuItem.Size = New System.Drawing.Size(71, 20)
        Me.ProgramaToolStripMenuItem.Text = "Programa"
        '
        'CerrarToolStripMenuItem
        '
        Me.CerrarToolStripMenuItem.Name = "CerrarToolStripMenuItem"
        Me.CerrarToolStripMenuItem.Size = New System.Drawing.Size(106, 22)
        Me.CerrarToolStripMenuItem.Text = "Cerrar"
        '
        'ReporteToolStripMenuItem
        '
        Me.ReporteToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GenerarReporteToolStripMenuItem})
        Me.ReporteToolStripMenuItem.Name = "ReporteToolStripMenuItem"
        Me.ReporteToolStripMenuItem.Size = New System.Drawing.Size(60, 20)
        Me.ReporteToolStripMenuItem.Text = "Reporte"
        '
        'GenerarReporteToolStripMenuItem
        '
        Me.GenerarReporteToolStripMenuItem.Name = "GenerarReporteToolStripMenuItem"
        Me.GenerarReporteToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.GenerarReporteToolStripMenuItem.Text = "Generar Reporte"
        '
        'AyudaToolStripMenuItem
        '
        Me.AyudaToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AbrirAyudaToolStripMenuItem, Me.AyudaTécnicaToolStripMenuItem})
        Me.AyudaToolStripMenuItem.Name = "AyudaToolStripMenuItem"
        Me.AyudaToolStripMenuItem.Size = New System.Drawing.Size(53, 20)
        Me.AyudaToolStripMenuItem.Text = "Ayuda"
        '
        'AbrirAyudaToolStripMenuItem
        '
        Me.AbrirAyudaToolStripMenuItem.Name = "AbrirAyudaToolStripMenuItem"
        Me.AbrirAyudaToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.AbrirAyudaToolStripMenuItem.Text = "Sobre este Software"
        '
        'AyudaTécnicaToolStripMenuItem
        '
        Me.AyudaTécnicaToolStripMenuItem.Name = "AyudaTécnicaToolStripMenuItem"
        Me.AyudaTécnicaToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.AyudaTécnicaToolStripMenuItem.Text = "Ayuda técnica"
        '
        'FlujoVolumetricoUnidades
        '
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.TemperaturaUnidades)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.TempAeroenfriador)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Label15)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.FlujoVolumetrico)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Label22)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Potencia)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Label25)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.RPM)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Label24)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Area)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Label23)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Label20)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.PresionUnidades)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Button2)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Button1)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.FlujoMasico)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Label16)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Label17)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Label18)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Tdescarga)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Pdescarga)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Label11)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Diametro)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Label9)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.HumedadAbsoluta)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Label8)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Label7)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Label6)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Label5)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Label4)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Label3)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Stroke)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.HumedadRelativa)
        Me.FlujoVolumetricoUnidades.Controls.Add(Me.Tambiental)
        Me.FlujoVolumetricoUnidades.Location = New System.Drawing.Point(617, 270)
        Me.FlujoVolumetricoUnidades.Name = "FlujoVolumetricoUnidades"
        Me.FlujoVolumetricoUnidades.Size = New System.Drawing.Size(555, 330)
        Me.FlujoVolumetricoUnidades.TabIndex = 2
        Me.FlujoVolumetricoUnidades.TabStop = False
        Me.FlujoVolumetricoUnidades.Text = "Sistema de compresión"
        '
        'TemperaturaUnidades
        '
        Me.TemperaturaUnidades.FormattingEnabled = True
        Me.TemperaturaUnidades.Items.AddRange(New Object() {"[°C]", "[K]", "[F]", "[R]"})
        Me.TemperaturaUnidades.Location = New System.Drawing.Point(399, 222)
        Me.TemperaturaUnidades.Name = "TemperaturaUnidades"
        Me.TemperaturaUnidades.Size = New System.Drawing.Size(55, 21)
        Me.TemperaturaUnidades.TabIndex = 42
        '
        'TempAeroenfriador
        '
        Me.TempAeroenfriador.Location = New System.Drawing.Point(460, 223)
        Me.TempAeroenfriador.Name = "TempAeroenfriador"
        Me.TempAeroenfriador.Size = New System.Drawing.Size(50, 20)
        Me.TempAeroenfriador.TabIndex = 41
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(260, 226)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(133, 13)
        Me.Label15.TabIndex = 40
        Me.Label15.Text = "Temperatura Aeroenfriador"
        '
        'FlujoVolumetrico
        '
        Me.FlujoVolumetrico.Location = New System.Drawing.Point(460, 172)
        Me.FlujoVolumetrico.Name = "FlujoVolumetrico"
        Me.FlujoVolumetrico.Size = New System.Drawing.Size(70, 20)
        Me.FlujoVolumetrico.TabIndex = 39
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(260, 175)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(129, 13)
        Me.Label22.TabIndex = 38
        Me.Label22.Text = "Flujo volumétrico [m^3/hr]"
        '
        'Potencia
        '
        Me.Potencia.Location = New System.Drawing.Point(460, 197)
        Me.Potencia.Name = "Potencia"
        Me.Potencia.Size = New System.Drawing.Size(70, 20)
        Me.Potencia.TabIndex = 32
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(260, 200)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(73, 13)
        Me.Label25.TabIndex = 31
        Me.Label25.Text = "Potencia [Kw]"
        '
        'RPM
        '
        Me.RPM.Location = New System.Drawing.Point(177, 275)
        Me.RPM.Name = "RPM"
        Me.RPM.Size = New System.Drawing.Size(70, 20)
        Me.RPM.TabIndex = 30
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(9, 278)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(31, 13)
        Me.Label24.TabIndex = 29
        Me.Label24.Text = "RPM"
        '
        'Area
        '
        Me.Area.Location = New System.Drawing.Point(177, 246)
        Me.Area.Name = "Area"
        Me.Area.Size = New System.Drawing.Size(70, 20)
        Me.Area.TabIndex = 28
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(9, 249)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(58, 13)
        Me.Label23.TabIndex = 27
        Me.Label23.Text = "Área [in^2]"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(49, 158)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(134, 13)
        Me.Label20.TabIndex = 25
        Me.Label20.Text = "Condiciones de la máquina"
        '
        'PresionUnidades
        '
        Me.PresionUnidades.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.PresionUnidades.FormattingEnabled = True
        Me.PresionUnidades.Items.AddRange(New Object() {"[psi]", "[Pa]", "[KPa]", "[MPa]", "[bar]", "[m]", "[mmHg]"})
        Me.PresionUnidades.Location = New System.Drawing.Point(399, 97)
        Me.PresionUnidades.Name = "PresionUnidades"
        Me.PresionUnidades.Size = New System.Drawing.Size(55, 21)
        Me.PresionUnidades.TabIndex = 22
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(342, 263)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(138, 33)
        Me.Button2.TabIndex = 21
        Me.Button2.Text = "Calcular"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(319, 38)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(196, 27)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Definir condiciones ambientales"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'FlujoMasico
        '
        Me.FlujoMasico.Location = New System.Drawing.Point(460, 146)
        Me.FlujoMasico.Name = "FlujoMasico"
        Me.FlujoMasico.Size = New System.Drawing.Size(70, 20)
        Me.FlujoMasico.TabIndex = 20
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(260, 148)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(97, 13)
        Me.Label16.TabIndex = 19
        Me.Label16.Text = "Flujo másico [Kg/s]"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(260, 124)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(146, 13)
        Me.Label17.TabIndex = 18
        Me.Label17.Text = "Temperatura de descarga [R]"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(260, 100)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(104, 13)
        Me.Label18.TabIndex = 17
        Me.Label18.Text = "Presión de descarga"
        '
        'Tdescarga
        '
        Me.Tdescarga.Location = New System.Drawing.Point(460, 121)
        Me.Tdescarga.Name = "Tdescarga"
        Me.Tdescarga.Size = New System.Drawing.Size(70, 20)
        Me.Tdescarga.TabIndex = 16
        '
        'Pdescarga
        '
        Me.Pdescarga.Location = New System.Drawing.Point(460, 97)
        Me.Pdescarga.Name = "Pdescarga"
        Me.Pdescarga.Size = New System.Drawing.Size(70, 20)
        Me.Pdescarga.TabIndex = 15
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(289, 76)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(122, 13)
        Me.Label11.TabIndex = 14
        Me.Label11.Text = "Condiciones cambiantes"
        '
        'Diametro
        '
        Me.Diametro.Location = New System.Drawing.Point(177, 215)
        Me.Diametro.Name = "Diametro"
        Me.Diametro.Size = New System.Drawing.Size(70, 20)
        Me.Diametro.TabIndex = 11
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(7, 218)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(66, 13)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "Diámetro [in]"
        '
        'HumedadAbsoluta
        '
        Me.HumedadAbsoluta.Location = New System.Drawing.Point(177, 98)
        Me.HumedadAbsoluta.Name = "HumedadAbsoluta"
        Me.HumedadAbsoluta.Size = New System.Drawing.Size(70, 20)
        Me.HumedadAbsoluta.TabIndex = 9
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(7, 188)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(55, 13)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Stroke [in]"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(9, 101)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(155, 13)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Humedad absoluta [gr/Kg(aire)]"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 52)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(136, 13)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Temperatura de succión °C"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(9, 76)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(90, 13)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Humedad relativa"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(49, 20)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(124, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Condiciones ambientales"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(281, 20)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(245, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Condiciones ambientales para el aire de la succión"
        '
        'Stroke
        '
        Me.Stroke.Location = New System.Drawing.Point(177, 184)
        Me.Stroke.Name = "Stroke"
        Me.Stroke.Size = New System.Drawing.Size(70, 20)
        Me.Stroke.TabIndex = 2
        '
        'HumedadRelativa
        '
        Me.HumedadRelativa.Location = New System.Drawing.Point(177, 73)
        Me.HumedadRelativa.Name = "HumedadRelativa"
        Me.HumedadRelativa.Size = New System.Drawing.Size(70, 20)
        Me.HumedadRelativa.TabIndex = 1
        '
        'Tambiental
        '
        Me.Tambiental.Location = New System.Drawing.Point(177, 49)
        Me.Tambiental.Name = "Tambiental"
        Me.Tambiental.Size = New System.Drawing.Size(70, 20)
        Me.Tambiental.TabIndex = 0
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(TabPage1)
        Me.TabControl1.Location = New System.Drawing.Point(166, 270)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(445, 330)
        Me.TabControl1.TabIndex = 3
        '
        'Timer1
        '
        Me.Timer1.Interval = 700
        '
        'SantaBarbara_Compresores
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(1216, 612)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.FlujoVolumetricoUnidades)
        Me.Controls.Add(Me.NombreMaquina)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "SantaBarbara_Compresores"
        Me.Text = "Jusepin_1"
        TabPage1.ResumeLayout(False)
        TabPage1.PerformLayout()
        Me.NombreMaquina.ResumeLayout(False)
        Me.NombreMaquina.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.FlujoVolumetricoUnidades.ResumeLayout(False)
        Me.FlujoVolumetricoUnidades.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents NombreMaquina As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents FlujoVolumetricoUnidades As System.Windows.Forms.GroupBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents HumedadRelativa As System.Windows.Forms.TextBox
    Friend WithEvents Tambiental As System.Windows.Forms.TextBox
    Friend WithEvents Stroke As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents HumedadAbsoluta As System.Windows.Forms.TextBox
    Friend WithEvents Diametro As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents FlujoMasico As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Tdescarga As System.Windows.Forms.TextBox
    Friend WithEvents Pdescarga As System.Windows.Forms.TextBox
    Friend WithEvents PresionUnidades As System.Windows.Forms.ComboBox
    Friend WithEvents TextDescargaCompresor2 As System.Windows.Forms.Label
    Friend WithEvents TextTempIntercambiador As System.Windows.Forms.Label
    Friend WithEvents TextDescargaCompresor1 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents RPM As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Area As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Potencia As System.Windows.Forms.TextBox
    Friend WithEvents FlujoVolumetrico As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TempRucio As System.Windows.Forms.Label
    Friend WithEvents TempAeroenfriador As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TemperaturaUnidades As System.Windows.Forms.ComboBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ProgramaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CerrarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReporteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GenerarReporteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AyudaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AbrirAyudaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AyudaTécnicaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Titulo As System.Windows.Forms.Label
    Friend WithEvents InfoCondensado As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents InfoEnfriador1 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents InfoCompre2 As System.Windows.Forms.Label
    Friend WithEvents InfoCompre1 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents RelacionCompresion As System.Windows.Forms.Label
    Friend WithEvents InfoGlobal As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
End Class
