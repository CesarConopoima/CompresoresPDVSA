﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Inicio
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Inicio))
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LabelID = New System.Windows.Forms.Label()
        Me.LabelNombre = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.LabelUbicacion = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.LabelFecha = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.LabelContacto = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.LabelDescripcion = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.LabelSubsistema = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.FotoSantaBarbara = New System.Windows.Forms.PictureBox()
        Me.FotoSanJoaquin = New System.Windows.Forms.PictureBox()
        Me.FotoJusepin = New System.Windows.Forms.PictureBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.SubSistema2 = New System.Windows.Forms.PictureBox()
        Me.SubSistema1 = New System.Windows.Forms.PictureBox()
        Me.Mapa = New System.Windows.Forms.PictureBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Atajo4 = New System.Windows.Forms.Button()
        Me.Atajo3 = New System.Windows.Forms.Button()
        Me.Atajo2 = New System.Windows.Forms.Button()
        Me.Atajo1 = New System.Windows.Forms.Button()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.GroupBox1.SuspendLayout()
        CType(Me.FotoSantaBarbara, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FotoSanJoaquin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FotoJusepin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SubSistema2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SubSistema1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Mapa, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.CausesValidation = False
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button1.Location = New System.Drawing.Point(37, 37)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(139, 44)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Jusepin"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.CausesValidation = False
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(198, 37)
        Me.Button2.Name = "Button2"
        Me.Button2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button2.Size = New System.Drawing.Size(139, 44)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "Santa Barbara"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.CausesValidation = False
        Me.Button3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(359, 37)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(139, 44)
        Me.Button3.TabIndex = 3
        Me.Button3.Text = "Jose"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(44, 120)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "# ID de Planta"
        '
        'LabelID
        '
        Me.LabelID.AutoSize = True
        Me.LabelID.Location = New System.Drawing.Point(170, 120)
        Me.LabelID.Name = "LabelID"
        Me.LabelID.Size = New System.Drawing.Size(72, 13)
        Me.LabelID.TabIndex = 5
        Me.LabelID.Text = "Sin Selección"
        '
        'LabelNombre
        '
        Me.LabelNombre.AutoSize = True
        Me.LabelNombre.Location = New System.Drawing.Point(170, 157)
        Me.LabelNombre.Name = "LabelNombre"
        Me.LabelNombre.Size = New System.Drawing.Size(72, 13)
        Me.LabelNombre.TabIndex = 7
        Me.LabelNombre.Text = "Sin Selección"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(44, 157)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(92, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Nombre de Planta"
        '
        'LabelUbicacion
        '
        Me.LabelUbicacion.AutoSize = True
        Me.LabelUbicacion.Location = New System.Drawing.Point(170, 231)
        Me.LabelUbicacion.Name = "LabelUbicacion"
        Me.LabelUbicacion.Size = New System.Drawing.Size(72, 13)
        Me.LabelUbicacion.TabIndex = 11
        Me.LabelUbicacion.Text = "Sin Selección"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(44, 231)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(55, 13)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Ubicacion"
        '
        'LabelFecha
        '
        Me.LabelFecha.AutoSize = True
        Me.LabelFecha.Location = New System.Drawing.Point(170, 305)
        Me.LabelFecha.Name = "LabelFecha"
        Me.LabelFecha.Size = New System.Drawing.Size(72, 13)
        Me.LabelFecha.TabIndex = 13
        Me.LabelFecha.Text = "Sin Selección"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(44, 305)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(92, 13)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Ultima vez Abierto"
        '
        'LabelContacto
        '
        Me.LabelContacto.AutoSize = True
        Me.LabelContacto.Location = New System.Drawing.Point(170, 268)
        Me.LabelContacto.Name = "LabelContacto"
        Me.LabelContacto.Size = New System.Drawing.Size(72, 13)
        Me.LabelContacto.TabIndex = 15
        Me.LabelContacto.Text = "Sin Selección"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(44, 268)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(50, 13)
        Me.Label10.TabIndex = 14
        Me.Label10.Text = "Contacto"
        '
        'LabelDescripcion
        '
        Me.LabelDescripcion.AutoSize = True
        Me.LabelDescripcion.Location = New System.Drawing.Point(170, 194)
        Me.LabelDescripcion.Name = "LabelDescripcion"
        Me.LabelDescripcion.Size = New System.Drawing.Size(72, 13)
        Me.LabelDescripcion.TabIndex = 17
        Me.LabelDescripcion.Text = "Sin Selección"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(44, 194)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(63, 13)
        Me.Label12.TabIndex = 16
        Me.Label12.Text = "Descripcion"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.LabelSubsistema)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.FotoSantaBarbara)
        Me.GroupBox1.Controls.Add(Me.FotoSanJoaquin)
        Me.GroupBox1.Controls.Add(Me.FotoJusepin)
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Controls.Add(Me.SubSistema2)
        Me.GroupBox1.Controls.Add(Me.SubSistema1)
        Me.GroupBox1.Controls.Add(Me.LabelDescripcion)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.Mapa)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.LabelContacto)
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.LabelFecha)
        Me.GroupBox1.Controls.Add(Me.LabelID)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.LabelUbicacion)
        Me.GroupBox1.Controls.Add(Me.LabelNombre)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1100, 411)
        Me.GroupBox1.TabIndex = 18
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Lista de Planta"
        '
        'LabelSubsistema
        '
        Me.LabelSubsistema.AutoSize = True
        Me.LabelSubsistema.Location = New System.Drawing.Point(170, 333)
        Me.LabelSubsistema.Name = "LabelSubsistema"
        Me.LabelSubsistema.Size = New System.Drawing.Size(72, 13)
        Me.LabelSubsistema.TabIndex = 25
        Me.LabelSubsistema.Text = "Sin Selección"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(44, 333)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 13)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "Subsistema"
        '
        'FotoSantaBarbara
        '
        Me.FotoSantaBarbara.Image = CType(resources.GetObject("FotoSantaBarbara.Image"), System.Drawing.Image)
        Me.FotoSantaBarbara.Location = New System.Drawing.Point(518, 116)
        Me.FotoSantaBarbara.Name = "FotoSantaBarbara"
        Me.FotoSantaBarbara.Size = New System.Drawing.Size(307, 182)
        Me.FotoSantaBarbara.TabIndex = 23
        Me.FotoSantaBarbara.TabStop = False
        '
        'FotoSanJoaquin
        '
        Me.FotoSanJoaquin.Image = CType(resources.GetObject("FotoSanJoaquin.Image"), System.Drawing.Image)
        Me.FotoSanJoaquin.Location = New System.Drawing.Point(878, 22)
        Me.FotoSanJoaquin.Name = "FotoSanJoaquin"
        Me.FotoSanJoaquin.Size = New System.Drawing.Size(202, 124)
        Me.FotoSanJoaquin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.FotoSanJoaquin.TabIndex = 22
        Me.FotoSanJoaquin.TabStop = False
        '
        'FotoJusepin
        '
        Me.FotoJusepin.Image = CType(resources.GetObject("FotoJusepin.Image"), System.Drawing.Image)
        Me.FotoJusepin.Location = New System.Drawing.Point(518, 116)
        Me.FotoJusepin.Name = "FotoJusepin"
        Me.FotoJusepin.Size = New System.Drawing.Size(307, 180)
        Me.FotoJusepin.TabIndex = 21
        Me.FotoJusepin.TabStop = False
        '
        'Button4
        '
        Me.Button4.CausesValidation = False
        Me.Button4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button4.Location = New System.Drawing.Point(371, 333)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(139, 44)
        Me.Button4.TabIndex = 20
        Me.Button4.Text = "Abrir"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'SubSistema2
        '
        Me.SubSistema2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.SubSistema2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SubSistema2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.SubSistema2.Location = New System.Drawing.Point(739, 302)
        Me.SubSistema2.Name = "SubSistema2"
        Me.SubSistema2.Size = New System.Drawing.Size(280, 103)
        Me.SubSistema2.TabIndex = 19
        Me.SubSistema2.TabStop = False
        '
        'SubSistema1
        '
        Me.SubSistema1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.SubSistema1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SubSistema1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.SubSistema1.Location = New System.Drawing.Point(518, 302)
        Me.SubSistema1.Name = "SubSistema1"
        Me.SubSistema1.Size = New System.Drawing.Size(280, 103)
        Me.SubSistema1.TabIndex = 18
        Me.SubSistema1.TabStop = False
        '
        'Mapa
        '
        Me.Mapa.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Mapa.Image = CType(resources.GetObject("Mapa.Image"), System.Drawing.Image)
        Me.Mapa.Location = New System.Drawing.Point(518, 19)
        Me.Mapa.Name = "Mapa"
        Me.Mapa.Size = New System.Drawing.Size(567, 281)
        Me.Mapa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Mapa.TabIndex = 0
        Me.Mapa.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Atajo4)
        Me.GroupBox2.Controls.Add(Me.Atajo3)
        Me.GroupBox2.Controls.Add(Me.Atajo2)
        Me.GroupBox2.Controls.Add(Me.Atajo1)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 417)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(661, 100)
        Me.GroupBox2.TabIndex = 19
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Panel de Atajos"
        '
        'Atajo4
        '
        Me.Atajo4.CausesValidation = False
        Me.Atajo4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Atajo4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Atajo4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Atajo4.Location = New System.Drawing.Point(502, 26)
        Me.Atajo4.Name = "Atajo4"
        Me.Atajo4.Size = New System.Drawing.Size(127, 52)
        Me.Atajo4.TabIndex = 5
        Me.Atajo4.Text = "Santa Barbara " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Sub Sist. Compresores " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "22/01/2013"
        Me.Atajo4.UseVisualStyleBackColor = True
        '
        'Atajo3
        '
        Me.Atajo3.CausesValidation = False
        Me.Atajo3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Atajo3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Atajo3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Atajo3.Location = New System.Drawing.Point(347, 26)
        Me.Atajo3.Name = "Atajo3"
        Me.Atajo3.Size = New System.Drawing.Size(127, 52)
        Me.Atajo3.TabIndex = 4
        Me.Atajo3.Text = "Santa Barbara " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Sub Sist. Compresores " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "22/01/2013"
        Me.Atajo3.UseVisualStyleBackColor = True
        '
        'Atajo2
        '
        Me.Atajo2.CausesValidation = False
        Me.Atajo2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Atajo2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Atajo2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Atajo2.Location = New System.Drawing.Point(192, 26)
        Me.Atajo2.Name = "Atajo2"
        Me.Atajo2.Size = New System.Drawing.Size(127, 52)
        Me.Atajo2.TabIndex = 3
        Me.Atajo2.Text = "Santa Barbara " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Sub Sist. Compresores " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "22/01/2013"
        Me.Atajo2.UseVisualStyleBackColor = True
        '
        'Atajo1
        '
        Me.Atajo1.CausesValidation = False
        Me.Atajo1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Atajo1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Atajo1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Atajo1.Location = New System.Drawing.Point(37, 26)
        Me.Atajo1.Name = "Atajo1"
        Me.Atajo1.Size = New System.Drawing.Size(127, 52)
        Me.Atajo1.TabIndex = 2
        Me.Atajo1.Text = "Santa Barbara " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Sub Sist. Compresores " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "22/01/2013"
        Me.Atajo1.UseVisualStyleBackColor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(792, 429)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(246, 100)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 8
        Me.PictureBox2.TabStop = False
        '
        'Inicio
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1126, 532)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PictureBox2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Inicio"
        Me.Text = "MikeSIM"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.FotoSantaBarbara, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FotoSanJoaquin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FotoJusepin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SubSistema2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SubSistema1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Mapa, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Mapa As System.Windows.Forms.PictureBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents LabelID As System.Windows.Forms.Label
    Friend WithEvents LabelNombre As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents LabelUbicacion As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents LabelFecha As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents LabelContacto As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents LabelDescripcion As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents SubSistema2 As System.Windows.Forms.PictureBox
    Friend WithEvents SubSistema1 As System.Windows.Forms.PictureBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Atajo1 As System.Windows.Forms.Button
    Friend WithEvents FotoSantaBarbara As System.Windows.Forms.PictureBox
    Friend WithEvents FotoSanJoaquin As System.Windows.Forms.PictureBox
    Friend WithEvents FotoJusepin As System.Windows.Forms.PictureBox
    Friend WithEvents Atajo4 As System.Windows.Forms.Button
    Friend WithEvents Atajo3 As System.Windows.Forms.Button
    Friend WithEvents Atajo2 As System.Windows.Forms.Button
    Friend WithEvents LabelSubsistema As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label

End Class
